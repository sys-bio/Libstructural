

from .structural import *

__version__ = structural.getVersion()