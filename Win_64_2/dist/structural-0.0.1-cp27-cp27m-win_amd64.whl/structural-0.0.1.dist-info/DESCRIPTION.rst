libStructural
=======================

**libStructural** API provides a wide variety of methods that permit access to the constraint information in the stoichiometry matrix. 


